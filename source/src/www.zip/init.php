<?php
include("common.php");
$template=new my_template;