#!/bin/bash

cp common.php /var/www/html/common.php

